using System.Collections.Generic;

namespace Alklog_KL
{
    public class Csucs
    {
        public int Id
        {
            get; set;
        }

        public List<int> Elek = new List<int>();

        public List<int> ForditottElek = new List<int>();

        public bool Meglatogatva
        {
            get; set;
        }

        public Csucs(int id)
        {
            Id = id;
        }

        public void elHozzaadasa(int id)
        {
            Elek.Add(id);
        }

        public void forditottElHozzaadasa(int id)
        {
            ForditottElek.Add(id);
        }
    }
}