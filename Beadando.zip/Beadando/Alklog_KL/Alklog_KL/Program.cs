﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace Alklog_KL
{
    public class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Input file beolvasása...");
            Console.WriteLine();
            Console.WriteLine("Input file gráf SCC száma: " + SCCMeret("input.txt"));
        }

        public static Dictionary<int, Csucs> grafInit(string file)
        {
            Dictionary<int, Csucs> graf = new Dictionary<int, Csucs>();
            StreamReader sr = new StreamReader("input.txt");

            while (!sr.EndOfStream)
            {
                List<int> temp = sr.ReadLine().Split('\t', ' ', ',').Where(value => !string.IsNullOrWhiteSpace(value)).Select(int.Parse).ToList();

                if (!graf.ContainsKey(temp[0]))
                {
                    graf.Add(temp[0], new Csucs(temp[0]));
                }
                if (!graf.ContainsKey(temp[1]))
                {
                    graf.Add(temp[1], new Csucs(temp[1]));
                }

                graf[temp[0]].elHozzaadasa(temp[1]);
                graf[temp[1]].forditottElHozzaadasa(temp[0]);
            }

            return graf;
        }

        private static void SCC(Dictionary<int, Csucs> graf, Csucs kezdoCsucs)
        {
            var verem = new Stack<Csucs>();
            verem.Push(kezdoCsucs);
            while (verem.Count > 0)
            {
                Csucs csucs = verem.Pop();
                csucs.Meglatogatva = true;

                var csucsok = csucs.Elek.ToList();
                csucsok.Reverse();
                foreach (int id in csucsok)
                {
                    var el = graf[id];
                    if (!el.Meglatogatva) verem.Push(el);
                }
            }
        }

        private static void ismeretlenCsucsok(Dictionary<int, Csucs> graf)
        {
            foreach (Csucs csucs in graf.Values)
                csucs.Meglatogatva = false;
        }

        public static int SCCMeret(string file)
        {
            var graf = grafInit(file);

            ismeretlenCsucsok(graf);

            foreach (Csucs csucs in graf.Values)
            {
                if (!csucs.Meglatogatva)
                {
                    SCC(graf, csucs);
                }
            }

            int count = 0;
            foreach (Csucs csucs in graf.Values)
            {
                count++;
            }

            return count;
        }
    }
}
